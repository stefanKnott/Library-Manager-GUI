var searchData=
[
  ['date',['Date',['../class_date.html',1,'']]],
  ['displayreport',['displayReport',['../class_book.html#a9624bb0abec9d90c9ba5df076d1a4688',1,'Book']]]
];
