var searchData=
[
  ['addbook',['addBook',['../classexpandable_array.html#a192b5c41e8147e5d005836a10131761a',1,'expandableArray']]],
  ['addhandler',['addHandler',['../classlib_manager.html#a89a6aa09c55807fc68a1782ead957446',1,'libManager']]]
];
