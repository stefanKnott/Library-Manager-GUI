var searchData=
[
  ['getrenter',['getRenter',['../class_book.html#af80f19eb1d82d02842aa2e3ea3992e7d',1,'Book']]],
  ['getrentstatus',['getRentStatus',['../class_book.html#aa8096caa520f29d6b9d8a1c7048603a0',1,'Book']]],
  ['gettitle',['getTitle',['../class_book.html#a71745ca59c0db6c376e9f398b0b16ddb',1,'Book']]]
];
