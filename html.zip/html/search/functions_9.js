var searchData=
[
  ['readfromfile',['readFromFile',['../classexpandable_array.html#acdf5acc4ee1100857b682ac601a71b61',1,'expandableArray']]],
  ['readinhandler',['readInHandler',['../classlib_manager.html#aee0547a7487f9f9b82efed3029a84a91',1,'libManager']]],
  ['removebook',['removeBook',['../classexpandable_array.html#ac11d81f2f509368fa30340d27808e059',1,'expandableArray']]],
  ['rmvhandler',['rmvHandler',['../classlib_manager.html#aa8574df3ab4dc3cee402c3af811641b9',1,'libManager']]]
];
